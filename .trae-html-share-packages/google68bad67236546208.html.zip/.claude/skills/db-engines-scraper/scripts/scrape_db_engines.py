# -*- coding: utf-8 -*-
"""
抓取 DB-Engines 排名页 (https://db-engines.com/en/ranking) 的 Top N 系统，
并进入每个系统的内页提取 "Editorial information provided by DB-Engines" 表格中的：
Description / Website / Developer / Initial release / Current release / License

结果保存为 database-info.json

用法:
    python scrape_db_engines.py            # 默认抓取全部系统（约 434 个）
    python scrape_db_engines.py --top 20   # 只抓排名前 N 个
"""

import argparse
import json
import os
import re
import sys
import time
import unicodedata
import warnings
from pathlib import Path

# Windows 终端默认 GBK 编码，打印中文/特殊字符会乱码或报错，统一切换为 UTF-8
for _stream in (sys.stdout, sys.stderr):
    if hasattr(_stream, "reconfigure"):
        _stream.reconfigure(encoding="utf-8", errors="replace")

import requests
from bs4 import BeautifulSoup

# 允许从任意目录运行时仍能 import 同目录的 diff_utils 模块
sys.path.insert(0, str(Path(__file__).resolve().parent))
from diff_utils import write_diff_report  # noqa: E402

RANKING_URL = "https://db-engines.com/en/ranking"
BASE_URL = "https://db-engines.com"
OUTPUT_FILE = "database-info.json"

# 内页需要提取的字段（attribute 文本 -> 输出字段名）
TARGET_FIELDS = {
    "Description": "description",
    "Website": "website",
    "Developer": "developer",
    "Initial release": "initial_release",
    "Current release": "current_release",
    "License": "license",
}

# 排名页 Database Model 列中单一模型简称 -> 全称 的映射。
# 站点对单模型系统使用简称显示（如 "Relational"），Multi-model 悬浮框中则用全称
# （如 "Relational DBMS"）。此处统一为全称，与 Multi-model 展开后的风格保持一致。
MODEL_FULL_NAME = {
    "Relational": "Relational DBMS",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/126.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

# 企业代理环境下本机可能缺少代理的根证书，导致 requests 校验证书失败。
# 若环境变量 CURL_CA_BUNDLE 指向有效的 CA 包（curl 能正常访问说明证书链可用），
# 则优先使用它；否则关闭证书校验并给出提示（仅限抓取公开数据场景）。
_CA_BUNDLE = os.environ.get("CURL_CA_BUNDLE") or os.environ.get("REQUESTS_CA_BUNDLE")
if _CA_BUNDLE and os.path.isfile(_CA_BUNDLE):
    VERIFY: "bool | str" = _CA_BUNDLE
else:
    VERIFY = False
    warnings.filterwarnings("ignore", message="Unverified HTTPS request")
    print("[提示] 未找到可用 CA 证书包，已关闭 SSL 证书校验（仅用于公开数据抓取）", file=sys.stderr)


def fetch(url: str, retries: int = 3, timeout: int = 30) -> str:
    """带重试的页面下载，返回 HTML 文本。"""
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=timeout, verify=VERIFY)
            resp.raise_for_status()
            resp.encoding = "utf-8"
            return resp.text
        except requests.RequestException as e:
            last_err = e
            print(f"  [警告] 第 {attempt} 次请求失败: {e}", file=sys.stderr)
            time.sleep(2 * attempt)
    raise RuntimeError(f"下载失败（重试 {retries} 次后放弃）: {url}") from last_err


def clean_text(text: str) -> str:
    """清洗文本：去软连字符、unicode 规范化、压缩空白。"""
    if not text:
        return ""
    text = text.replace("­", "")  # 软连字符 &shy;
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([,;])", r"\1", text)  # 修正 "Relational , Multi-model" 这类逗号前空格
    return text.strip()


def cell_text_without_infobox(cell) -> str:
    """
    取单元格文本，剔除 <span class=info> 悬浮说明框
    （说明框里是补充注释，不属于正文字段值）。
    """
    for span in cell.select("span.info"):
        span.decompose()
    return clean_text(cell.get_text(" ", strip=True))


def parse_database_model(cell) -> str:
    """
    解析排名页的 Database Model 列：
    - 不含 Multi-model 时，返回主模型文本，并按 MODEL_FULL_NAME 映射为全称
      （如 "Relational" -> "Relational DBMS"）；
    - 含 Multi-model 时，读取悬浮框 <span class=infobox> 中的细分模型列表，
      以 ", " 连接替代，如 "Relational DBMS, Document store, Graph DBMS"。
      （Databricks 这类多主模型的，悬浮框里会有多个 <b>，全部按顺序保留）
    """
    if "Multi-model" not in cell.get_text():
        text = cell_text_without_infobox(cell)
        return MODEL_FULL_NAME.get(text, text)

    infobox = cell.select_one("span.infobox")
    if infobox is None:
        text = cell_text_without_infobox(cell)
        return MODEL_FULL_NAME.get(text, text)

    # infobox 内以 <br> 分隔各个模型，<b> 为主模型；get_text 会把相邻文本拼接，
    # 因此先统一用分隔符替换 <br> 再拆分清洗
    for br in infobox.find_all("br"):
        br.replace_with("\n")
    models = [clean_text(t) for t in infobox.get_text().split("\n")]
    models = [m for m in models if m]
    # 个别厂商（如 CockroachDB）会在 infobox 里塞整段营销文案而非标准模型名，
    # 过滤掉明显过长的非模型文本（标准模型名均不超过 30 字符）
    models = [m for m in models if len(m) <= 30]
    return ", ".join(models) if models else cell_text_without_infobox(cell)


def parse_ranking(html: str, top_n: "int | None") -> list[dict]:
    """
    解析排名页，按 Rank 第一列（当月排名）顺序返回记录：
    {rank, dbms, database_model, detail_url}
    top_n 为 None 时返回全部系统，否则只返回前 top_n 条。
    """
    soup = BeautifulSoup(html, "lxml")
    table = soup.find("table", class_="dbi")
    if table is None:
        raise RuntimeError("未找到排名表格 <table class=dbi>，页面结构可能已变更")

    # 抓取月份说明，如 "434 systems in ranking, July 2026"
    caption = table.find("td", colspan="99")
    month = ""
    if caption:
        m = re.search(r"ranking,\s*(.+)$", clean_text(caption.get_text()))
        month = m.group(1) if m else ""

    results = []
    # 数据行特征：内含 <th class="pad-l">（DBMS 列）。表头行不含 a 链接，自动被过滤。
    for row in table.find_all("tr"):
        th_dbms = row.find("th", class_="pad-l")
        th_model = row.find("th", class_="small pad-r")
        rank_td = row.find("td")
        if not (th_dbms and th_model and rank_td):
            continue
        a = th_dbms.find("a", href=True)
        if not a:
            continue

        rank_text = clean_text(rank_td.get_text()).rstrip(".")
        if not rank_text.isdigit():
            continue  # 跳过表头行

        detail_url = a["href"]
        if detail_url.startswith("/"):
            detail_url = BASE_URL + detail_url

        # 注意：部分厂商会在 <a> 内嵌 "Detailed vendor-provided information available"
        # 悬浮框（span.info），必须剔除，否则 dbms 名会带尾巴
        results.append(
            {
                "rank": int(rank_text),
                "dbms": cell_text_without_infobox(a),
                "database_model": parse_database_model(th_model),
                "detail_url": detail_url,
            }
        )
        if top_n is not None and len(results) >= top_n:
            break

    return month, results


def parse_detail(html: str) -> dict:
    """
    解析系统内页，从 "Editorial information provided by DB-Engines"
    表格中提取目标字段。字段缺失时留空字符串。
    """
    soup = BeautifulSoup(html, "lxml")
    info = {out_key: "" for out_key in TARGET_FIELDS.values()}

    # 定位 Editorial 表格：通过 headline 单元格文本确认
    target_table = None
    for table in soup.find_all("table", class_="tools"):
        headline = table.find("td", class_="headline")
        if headline and "Editorial information provided by DB-Engines" in headline.get_text():
            target_table = table
            break
    if target_table is None:
        print("  [警告] 未找到 Editorial information 表格", file=sys.stderr)
        return info

    for row in target_table.find_all("tr"):
        attr_td = row.find("td", class_="attribute")
        val_td = row.find("td", class_="value")
        if not (attr_td and val_td):
            continue
        attr_name = clean_text(attr_td.get_text(" ", strip=True))
        # attribute 里可能带悬浮框文本，用“以目标字段名开头”做前缀匹配
        for field_label, out_key in TARGET_FIELDS.items():
            if attr_name.startswith(field_label):
                if out_key == "website":
                    # Website 取链接 href 更干净（显示文本带软连字符换行）
                    a = val_td.find("a", href=True)
                    info[out_key] = a["href"] if a else cell_text_without_infobox(val_td)
                else:
                    info[out_key] = cell_text_without_infobox(val_td)
                break

    return info


def main():
    parser = argparse.ArgumentParser(description="抓取 DB-Engines 排名数据库信息（默认全部系统）")
    parser.add_argument("--top", type=int, default=None, help="只抓排名前 N 个系统（默认不限制，抓取全部）")
    parser.add_argument("--delay", type=float, default=1.5, help="内页请求间隔秒数（默认 1.5）")
    parser.add_argument("-o", "--output", default=OUTPUT_FILE, help=f"输出文件名（默认 {OUTPUT_FILE}）")
    args = parser.parse_args()

    print(f"[1/2] 下载排名页: {RANKING_URL}")
    html = fetch(RANKING_URL)
    month, entries = parse_ranking(html, args.top)
    scope = f"前 {len(entries)} 条" if args.top is not None else f"全部 {len(entries)} 条"
    print(f"      排名月份: {month or '未知'}，获取到{scope}记录")

    print(f"[2/2] 逐个抓取内页（间隔 {args.delay}s）...")
    records = []
    for i, entry in enumerate(entries, 1):
        print(f"  [{i}/{len(entries)}] #{entry['rank']} {entry['dbms']} -> {entry['detail_url']}")
        try:
            detail_html = fetch(entry["detail_url"])
            info = parse_detail(detail_html)
        except Exception as e:
            print(f"  [错误] {entry['dbms']} 内页抓取失败: {e}", file=sys.stderr)
            info = {out_key: "" for out_key in TARGET_FIELDS.values()}

        # *_cn 中文字段在抓取阶段统一留空，由后续翻译流程填充
        records.append({
            "rank": entry["rank"],
            "dbms": entry["dbms"],
            "database_model": entry["database_model"],
            "database_model_cn": "",
            "detail_url": entry["detail_url"],
            "description": info["description"],
            "description_cn": "",
            "website": info["website"],
            "developer": info["developer"],
            "developer_cn": "",
            "initial_release": info["initial_release"],
            "current_release": info["current_release"],
            "license": info["license"],
            "license_cn": "",
        })
        if i < len(entries):
            time.sleep(args.delay)

    output = {
        "source": RANKING_URL,
        "ranking_month": month,
        "top_n": args.top if args.top is not None else "all",
        "count": len(records),
        "databases": records,
    }

    # 写文件前保留旧数据，用于生成 diff 报告
    old_data = None
    if Path(args.output).exists():
        with open(args.output, encoding="utf-8") as f:
            old_data = json.load(f)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"完成！已保存 {len(records)} 条记录到 {args.output}")
    write_diff_report(output, old_data)


if __name__ == "__main__":
    main()
